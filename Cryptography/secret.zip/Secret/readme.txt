I found the password for zip file, but i dont know the hash type. Maybe you can decrypt it.

Here is the password hash: f25a2fc72690b780b2a14e140ef6a9e0

Regards, Mr Frog
